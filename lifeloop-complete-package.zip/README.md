# LifeLoop

An interactive emotional life simulator built with React + Vite.

## 🚀 Features
- Emotional stat engine (joy, sorrow, excitement, etc.)
- NPC interactions with trust + rewards
- Avatar photo + emoji overlay
- Daily rewards, infinite levels, minigames
- Installable as PWA
- Deploy-ready for Vercel, Netlify, Firebase

## 🛠 Deployment

### Vercel
- Link to GitHub
- Auto-detect Vite config
- Done ✅

### Netlify
- Use `netlify.toml`

### Firebase
- Run `firebase deploy`

Enjoy your emotional journey 🎮🧠
