export default function Game() {
  return (
    <div className="p-4 text-center">
      <h1 className="text-2xl font-bold">🎮 LifeLoop Game</h1>
      <p>Your emotional journey begins here...</p>
    </div>
  );
}
